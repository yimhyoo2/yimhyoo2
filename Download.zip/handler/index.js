const fs = require("fs")

module.exports = async (Client) => {

const SlashsArray = []

  fs.readdir(`./Comandos`, (error, folder) => {
  folder.forEach(subfolder => {
fs.readdir(`./Comandos/${subfolder}/`, (error, files) => { 
  files.forEach(files => {
      
  if(!files?.endsWith('.js')) return;
  files = require(`../Comandos/${subfolder}/${files}`);
  if(!files?.name) return;
  Client.slashCommands.set(files?.name, files);
   
  SlashsArray.push(files)
  });
    });
  });
});
  Client.on("ready", async () => {
    await Client.application.commands.set(SlashsArray)
    });
};