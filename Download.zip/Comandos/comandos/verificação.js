const Discord = require("discord.js")
const { QuickDB } = require("quick.db")
const db = new QuickDB()

module.exports = {
    name: "verificação", // Coloque o nome do comando
    description: "🎈 [ADM] Ative o sistema de verificação.", // Coloque a descrição do comando
    type: Discord.ApplicationCommandType.ChatInput,
    options: [
        {
            name: "cargo_verificado",
            description: "Mencione um cargo para o membro receber após se verificar.",
            type: Discord.ApplicationCommandOptionType.Role,
            required: true,
        },
        {
            name: "canal",
            description: "Mencione um canal de texto.",
            type: Discord.ApplicationCommandOptionType.Channel,
            required: false,
        }
    ],

    run: async (Client, interaction) => {

        if (!interaction.member.permissions.has(Discord.PermissionFlagsBits.ManageGuild)) {
            interaction.reply(`Olá ${interaction.user}, você não possui permissão para utilizar este comando.`)
        } else {
            let canal = interaction.options.getChannel("canal");
            if (!canal) canal = interaction.channel;

            let cargo = interaction.options.getRole("cargo_verificado");
            await db.set(`cargo_verificação_${interaction.guild.id}`, cargo.id);

            let embed_ephemeral = new Discord.EmbedBuilder()
                .setColor("2f3136")
                .setDescription(`Olá ${interaction.user}, o sistema foi ativado no canal ${canal} com sucesso.`);

            let embed_verificacao = new Discord.EmbedBuilder()
                .setColor("2f3136")
                .setDescription(`> **Para se verificar no nosso servidor, Basta clicar no botão logo abaixo escrito Verifique-se, Apos isso você será verificado automaticamente.**\n\n> **Não fique apertando no botão varias vezes, Caso faça isso estará sujeito a Castigo.**\n\n> *Caso de algum erro entre em contato diretamente com a equipe.*`);

            let botao = new Discord.ActionRowBuilder().addComponents(
                new Discord.ButtonBuilder()
                    .setCustomId("verificar")
                    .setEmoji("<a:black_simverificado_B13:1099196515462946816>")
                    .setLabel("Verifique-se")
                    .setStyle(Discord.ButtonStyle.Success)
            );

            interaction.reply({ embeds: [embed_ephemeral], ephemeral: true }).then(() => {
                canal.send({ embeds: [embed_verificacao], components: [botao] })
            })

            // Client.on("interactionCreate", async (interaction) => {
            //     if (interaction.isButton()) {

            //         let channellogs = Client.channels.cache.get("1098848775235186720") // ID do canal de logs
            //         const server = interaction.guild.members.cache.get(Client.user.id)

            //         channellogs.send({
            //             embeds: [
            //                 new Discord.EmbedBuilder()
            //                     .setDescription(`
            //                     **Nova verificação.**
                              
            //                     **Usuario verificado:** ${interaction.user}
                
            //                     **ID do usuario:** ${interaction.user.id}
                                
            //                     **Cargo recebido:** ${cargo}
                                
            //                     *Qualquer erro ou duvidas com o sistema, Entre em contato diretamente com a equipe.*`)
            //                     .setColor('Aqua')
            //                     .setTimestamp()
                                
            //             ],
                    }

                }
            }

