const Discord = require("discord.js")
const { ActivityType } = require('discord.js');
const config = require("./config.json")
const { QuickDB } = require("quick.db")
const db = new QuickDB()
const Client = new Discord.Client({ intents: 32767 });

module.exports = Client

Client.on("guildBanRemove", (member) => {
  let canal_logs2 = "1380734376601452614"; // Coloque o ID do canal de texto
  if (!canal_logs2) return;

  let embed = new Discord.EmbedBuilder()
    .setColor("Green")
    .setTitle(`✅ Membro Desbanido ✅`)
    .setTimestamp(new Date())
    .setDescription(`**Membro:** \n> ${member.user} \n**ID do membro:** \n> ${member.user.id}`);

  member.guild.channels.cache.get(canal_logs2).send({ embeds: [embed] }) // Caso queira que o usuário não seja mencionado, retire a parte do "content". 
})

Client.on("guildBanAdd", (member) => {
  let canal_logs1 = "1380734376601452614"; // Coloque o ID do canal de texto
  if (!canal_logs1) return;

  let embed = new Discord.EmbedBuilder()
    .setColor("Red")
    .setTitle(`❌ Membro Banido ❌`)
    .setTimestamp(new Date())
    .setDescription(`**Membro:** \n> ${member.user} \n**ID do membro:** \n> ${member.user.id}`);

  member.guild.channels.cache.get(canal_logs1).send({ embeds: [embed] }) // Caso queira que o usuário não seja mencionado, retire a parte do "content". 
})

Client.on('voiceStateUpdate', async (oldState, newState) => {

  const user = await Client.users.fetch(newState.id);
  let log = Client.channels.cache.get(`1380734376601452614`);
  let entrada = newState.channel;
  let saida = oldState.channel;

  if (!oldState.channel && newState.channel) {
    let embedsaida = new Discord.EmbedBuilder()

      .setTitle('🔊  Entrou no canal de voz  🔊')
      .setDescription(`**Membro:** \n> ${user} \n**ID do membro:** \n> ${user.id} \n\n**Canal de voz:** \n> ${entrada} \n**ID do canal:** \n> ${entrada.id}`)
      .setColor('Green')
      .setTimestamp()

    log.send({ embeds: [embedsaida] })

  } else {
    if (!newState.channel) {

      let embedentrada = new Discord.EmbedBuilder()
        .setTitle('🔇  Saiu do canal de voz  🔇')
        .setDescription(`**Membro:** \n> ${user} \n**ID do membro:** \n> ${user.id} \n\n**Canal de voz:** \n> ${saida} \n**ID do canal:** \n> ${saida.id}`)
        .setColor('Red')
        .setTimestamp()

      log.send({ embeds: [embedentrada] })
    }

    else {

      if (oldState.channel && newState.channel && oldState.channel !== newState.channel) {

        let embedmudou = new Discord.EmbedBuilder()
          .setTitle('🔊  Mudou de canal de voz  🔊')
          .setDescription(`**Membro:** \n> ${user} \n**ID do membro:** \n> ${user.id} \n\n**Canal de voz antigo:** \n> ${saida} \n**ID do canal:** \n> ${saida.id} \n\n**Canal de voz novo:** \n> ${entrada} \n**ID do canal:** \n> ${entrada.id}`)
          .setColor('Gold')
          .setTimestamp()

        log.send({ embeds: [embedmudou] })
      }

    }
  }
})

Client.on('messageCreate', message => {
  if (message.mentions.has(Client.user)) {
    message.reply('Olá! alguém me mencionou?');
  }
});


module.exports = async (Client, oldMember, newMember) => {

  const { guild } = newMember;


  if (!oldMember.premiumSince && newMember.premiumSince) {

    const embed = new MessageEmbed()
      .setColor("2f3136")
      .setAuthor({ name: `${newMember.user.username}`, iconURL: guild.iconURL({ dynamic: true, size: 512 }) })
      .setDescription(`🧡 ${newMember.user} impulsionou  o servidor !`)

    Client.guilds.cache.get(guild.id).channels.cache.get("1387891097371541655").send({ embeds: [embed] })
  }
}

Client.on("ready", () => {
  let canalPing = Client.channels.cache.get("1380734376601452614"); // Colocar o id do canal de ping
  if (!canalPing) return console.log(`Canal de ping do bot não encontrado`);
  canalPing.setName(`📡 Ping: Calculando...`);
  setInterval(() => {
    canalPing.setName(`📡 Ping: ${Client.ws.ping}ms`);
  }, 1000 * 60 * 4);
})

Client.on("ready", () => {
  let users = Client.guilds.cache.map(g => g.memberCount).reduce((a, b) => a + b)
  const compact = users.toLocaleString("pt-BR", { notation: 'compact' });
  let membro = Client.channels.cache.get("1380734376601452614"); // Colocar o id do canal de membros
  if (!membro) return console.log(`Canal de membros do bot não encontrado`);
  membro.setName(`📡 Membros: Calculando...`);
  setInterval(() => {
    membro.setName(`📡 Membros: ${compact}`);
  }, 1000 * 60 * 4);
})

Client.on("ready", () => {
  let guilds = Client.guilds.cache.size
  let sv = Client.channels.cache.get("1380734376601452614");// Colocar o id do canal de servidores
  if (!sv) return console.log(`Canal de servidores do bot não encontrado`);
  sv.setName(`📡 Servidores: Calculando...`);
  setInterval(() => {
    sv.setName(`📡 Servidores: ${guilds}`);
  }, 1000 * 60 * 4);
})


Client.on('interactionCreate', (interaction) => {

  if (interaction.type === Discord.InteractionType.ApplicationCommand) {
    const cmd = Client.slashCommands.get(interaction.commandName);
    if (!cmd) return interaction.reply(`Error`);
    interaction["member"] = interaction.guild.members.cache.get(interaction.user.id);
    cmd.run(Client, interaction)

  }
})

Client.on('interactionCreate', async interaction => {

  if (interaction.isButton()) {
    if (interaction.customId.startsWith("botao_modal")) {
      const modal = new Discord.ModalBuilder()
        .setCustomId('modal_sugestao')
        .setTitle(`Olá usuário, Nos diga qual é a sua sugestão.`)
      const sugestao3 = new Discord.TextInputBuilder()
        .setCustomId('sugestão')
        .setLabel('Qual sua sugestão?')
        .setStyle(Discord.TextInputStyle.Paragraph)

      const firstActionRow = new Discord.ActionRowBuilder().addComponents(sugestao3);
      modal.addComponents(firstActionRow)
      await interaction.showModal(modal);

      interaction.followUp({
        content: `${interaction.user}, Não abuse dessa função, caso contrario poderá e irá resultar em banimento.`,
        ephemeral: true
      })

    }
  }
  //

  if (!interaction.isModalSubmit()) return;
  if (interaction.customId === 'modal_sugestao') {
    const moment = require("moment")
    let channel = Client.channels.cache.get('1387978476874629232') //canal para o envio da sugestão.
    const sugestao2 = interaction.fields.getTextInputValue('sugestão');

    interaction.reply({
      content: `✅ | ${interaction.user}, Sua sugestão foi enviada com sucesso!`, ephemeral: true
    })

    channel.send({
      embeds: [new Discord.EmbedBuilder()
        .setColor('2f3136')
        .setAuthor({ name: `👤 - ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL({ dinamyc: true }) })
        .setFooter({ text: interaction.guild.name, iconURL: interaction.guild.iconURL({ dinamyc: true }) })
        .setThumbnail(interaction.user.displayAvatarURL({ format: "png", dinamyc: true, size: 4096 }))
        .setDescription(`**Horário da sugestão:**
<t:${moment(interaction.createdTimestamp).unix()}>(<t:${parseInt(interaction.createdTimestamp / 1000)}:R>)

**Sobre o usuário:**

**ID:** (\`${interaction.user.id}\`)
**Usuario que fez a sugestão:** ${interaction.user}
**Nome no discord:** \`${interaction.user.tag}\`

**Sugestão:**
\`\`\`${sugestao2}\`\`\``)
      ]
    })
  }
})

Client.on("messageCreate", (message) => {

  if (message.channel.id === "1387978476874629232" /*id do canal para auto reagir.*/) {

    let concordo = "✅"
    let nao_concordo = "❌"

    message.react(concordo).catch(e => { })
    message.react(nao_concordo).catch(e => { })

  } else { return; }
})

Client.on("interactionCreate", async (interaction) => {
  if (interaction.isButton()) {
    if (interaction.customId === "verificar") {
      let role_id = await db.get(`cargo_verificação_${interaction.guild.id}`);
      let role = interaction.guild.roles.cache.get(role_id);
      if (!role) return;
      interaction.member.roles.add(role.id)
      interaction.reply({ content: `*Ola ${interaction.user}, Você foi verificado com sucesso!*`, ephemeral: true })
    }
  }
})

// process.on("uncaughtException", (err) => {
//   console.log("Uncaught Exception: " + err);
// });

// process.on("unhandledRejection", (reason, promise) => {
//   console.log("[GRAVE] Rejeição possivelmente não tratada em: Promise ", promise, " motivo: ", reason.message);
// });


Client.on('ready', () => {
  console.log(`🔥 Estou online em ${Client.user.username}!`);
  Client.user.setPresence({
    activities: [{ name: `Minecraft`, type: ActivityType.Playing }],
    status: 'idle',
  });
})

Client.slashCommands = new Discord.Collection()
require('./handler')(Client)
Client.login(config.token)
